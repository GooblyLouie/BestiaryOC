/*
In NativeScript, a file with the same name as an XML file is known as
a code-behind file. The code-behind is a great place to place your view
logic, and to set up your page’s data binding.
*/

const HomeViewModel = require("./home-view-model");
const view = require("tns-core-modules/ui/core/view");
const frame = require("tns-core-modules/ui/frame");
const observable = require("tns-core-modules/data/observable");
const scrollView = require("tns-core-modules/ui/scroll-view");
const gridLayout = require("tns-core-modules/ui/layouts/grid-layout");
const label = require("tns-core-modules/ui/label");
const textField = require("tns-core-modules/ui/text-field");
const button = require("tns-core-modules/ui/button");
const pswitch = require("tns-core-modules/ui/switch");




function onNavigatingTo(args) {
    const page = args.object;
    data = page.navigationContext;
    vm = data.vm;
	vm.set("menuOn", data.menuOn);
	var menuRows = "";
	var menuGrid = new gridLayout.GridLayout();
	menuGrid = page.getViewById("menuGrid");
	for (i = 0; i < data.menuSize; i++) {
		if (i == 0)
			menuRows += "40";
		else
			menuRows += ", 40";
		var b = new button.Button();
		b.text = data.menuText[i];
		b.class = vm.get("tab");
		if (i == data.currentIndex) {
			b.class = vm.get("tabon");
		}
		else {
    		b.on("tap", (goto));
		}
		b.row = "" + i;
    	menuGrid.addChild(b);
	}
	page.css = "label { color: " + vm.get("tColor") + " } gridLayout { background-color: " + vm.get("light") + "}";
	menuGrid.rows = menuRows;

    ////////////////////////////////////////////////File reading code
	const fs = require('file-system');
	const f = fs.knownFolders.currentApp().getFile("monsters.txt");
    //console.log(f);
	f.readText().then(str => {
	    //const obj = JSON.parse(str);
	    obj = JSON.parse(str);
	    var lc = 1;
	    var rows = "10, auto";

	    for (var i = 0; i < obj.length; i++) {
	        var g = new gridLayout.GridLayout();
	        rows += ",10, auto";
	        g.col = "1";
	        g.row = "" + lc;
	        lc+=2;
	        g.rows = "auto, auto, auto, auto, auto";
	        g.columns = "*";
	        g.id = "" + i;

	        var l = new label.Label();
	        l.text = obj[i].Name;
	        l.row = 0;
	        l.colSpan = 3;
	        l.col = 1;
	        l.class = "header";
	        //l.on("tap", (toMonster));
	        g.addChild(l);

	        var l = new label.Label();
	        l.text = obj[i].Description.Challenge;
	        l.textWrap = true;
	        l.row = 1;
	        l.colSpan = 3;
	        l.col = 1;
	        l.class = "text";
	        g.addChild(l);

	        var l = new label.Label();
	        l.text = obj[i].Size + " " + obj[i].Type;
	        l.textWrap = true;
	        l.row = 2;
	        l.colSpan = 3;
	        l.col = 1;
	        l.class = "text";
	        g.addChild(l);

	        var l = new label.Label();
	        l.text = obj[i].Alignment;
	        l.textWrap = true;
	        l.row = 3;
	        l.colSpan = 3;
	        l.col = 1;
	        l.class = "text";
	        g.addChild(l);

	        var l = new label.Label();
	        l.text = "Hit Points: " + obj[i].HitPoints[0];
	        l.row = 4;
	        l.colSpan = 3;
	        l.col = 1;
	        l.class = "text";
	        g.addChild(l);
	        

	        g.on("tap", (toMonster));
	        page.getViewById("gl").addChild(g);

	    }
	    page.getViewById("gl").rows = rows;

	}).catch(err => { console.error(err); });

	page.bindingContext = vm;
}

function goto(args) {
	var modName = "home/" + data.menuText[args.object.row]
	navOpt = {
		moduleName: modName,
		context: {
			menuOn: data.menuOn,
			menuSize: data.menuSize,
			menuText: data.menuText,
			currentIndex: args.object.row,
			vm: vm
		}
	}
	frame.topmost().navigate(navOpt);
}

function pullMenu(args) {
	page = args.object.page;
	var vm = page.bindingContext;
	var menuSwitch;
	if (vm.get("menuOn") == "visible") {
		menuSwitch = "collapse";
	}
	else {
		menuSwitch = "visible";
	}
	vm.set("menuOn", menuSwitch);
	page.bindingContext = vm;
}



function onScroll(args) {
    const page = args.object.page;
    const vm = page.bindingContext;
    vm.set("status", "scrolling");
    setTimeout(() => {
        vm.set("status", "not scrolling");
    }, 300);
}

function toMonster(args) {
    var modName = "home/Monster";
    navOpt = {
        moduleName: modName,
        context: {
            menuOn: data.menuOn,
            menuSize: data.menuSize,
            menuText: data.menuText,
            currentIndex: -1,
            vm: vm,
            monster: obj[args.object.id],
            fileText: obj,
            index: args.object.id
        }
    }
    frame.topmost().navigate(navOpt);
}

function newM(args) {
	var blank = {};
	blank.HitPoints = [];
	blank.Description = {};

	blank.Name = "";
	blank.Size = "";
	blank.Type = "";
	blank.Tag = "";
	blank.Alignment = "";
	blank.AC = "";
   	blank.HitPoints[1] = "";
   	blank.HitPoints[0] = "";

   	blank.Speed = "";
   	blank.Strength = "";
   	blank.Dexterity = "";
   	blank.Intelligence = "";
   	blank.Constitution = "";
   	blank.Wisdom = "";
   	blank.Charisma = "";
   	blank.Description.SavingThrows = "";
   	blank.Description.Skills = "";
   	blank.Description.DamageVulnerabilities = "";
   	blank.Description.DamageResistances = "";
   	blank.Description.DamageImmunities = "";
   	blank.Description.ConditionImmunities = "";
   	blank.Description.Senses = "";
   	blank.Description.Languages = "";
   	blank.Description.Challenge = "";
    
   	obj.push(blank);

    var modName = "home/Monster";
    navOpt = {
        moduleName: modName,
        context: {
            menuOn: data.menuOn,
            menuSize: data.menuSize,
            menuText: data.menuText,
            currentIndex: -1,
            vm: vm,
            monster:blank,
            fileText: obj,
            index: obj.length-1
        }
    }
    frame.topmost().navigate(navOpt);
}

exports.pullMenu = pullMenu;
exports.onNavigatingTo = onNavigatingTo;
exports.onScroll = onScroll;
exports.toMonster = toMonster;
exports.newM = newM;