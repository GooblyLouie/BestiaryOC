/*
In NativeScript, a file with the same name as an XML file is known as
a code-behind file. The code-behind is a great place to place your view
logic, and to set up your page’s data binding.
*/

const HomeViewModel = require("./home-view-model");
const view = require("tns-core-modules/ui/core/view");
const frame = require("tns-core-modules/ui/frame");
const observable = require("tns-core-modules/data/observable");
const scrollView = require("tns-core-modules/ui/scroll-view");
const gridLayout = require("tns-core-modules/ui/layouts/grid-layout");
const label = require("tns-core-modules/ui/label");
const textField = require("tns-core-modules/ui/text-field");
const button = require("tns-core-modules/ui/button");
const pswitch = require("tns-core-modules/ui/switch");
var dialogs = require("tns-core-modules/ui/dialogs");
const fs = require("file-system");
const f = fs.knownFolders.currentApp().getFile("text.txt");


function onNavigatingTo(args) {
    vm = new observable.Observable();
    const page = args.object;
    //f.readText().then(str => {
    //	var obj = JSON.parse(str)
    //    gl = page.getViewById("gl");
    //    for (var i = 0; obj.size; i++) {
    //    	console.log("x");
    //    }
    //}).catch(err => { console.error(err); });
    data = page.navigationContext;
    vm.set("menuOn", "collapse");
    if (data != null) {
        vm = data.vm;
    	vm.set("menuOn", data.menuOn);
    	var menuRows = "";
    	var menuGrid = new gridLayout.GridLayout();
    	menuGrid = page.getViewById("menuGrid");
    	for (i = 0; i < data.menuSize; i++) {
    		if (i == 0)
    			menuRows += "40";
    		else
    			menuRows += ", 40";
    		var b = new button.Button();
    		b.text = data.menuText[i];
    		b.class = vm.get("tab");
    		if (i == data.currentIndex) {
    			b.class = vm.get("tabon");
    		}
    		else {
        		b.on("tap", (goto));
    		}
    		b.row = "" + i;
        	menuGrid.addChild(b);
    	}
    	menuGrid.rows = menuRows;
    	page.css = "label { color: " + vm.get("tColor") + " } tab { background-image: linear-gradient(to right, #191952, " + vm.get("bgColor") + "); }";
    }
	else {
		vm.set("bgColor", "#222255");
		vm.set("light", "#222222");
		vm.set("tColor", "#777777");
		vm.set("tabon", "tabonBlue");
		vm.set("tab", "tabBlue");
		page.css = "label { color: #777777 }";
    	var menuText = ["Bestiary", "Settings"];
    	navOpt = {
    		moduleName: "home/Bestiary",
    		context: {
    			menuOn: vm.get("menuOn"),
    			menuSize: menuText.length,
    			menuText: menuText,
    			currentIndex: 0,
    			vm: vm
    		}
    	}
    	frame.topmost().navigate(navOpt);
    }
    
    page.bindingContext = vm;
}

function goto(args) {
	var vm = args.object.page.bindingContext;
	var modName = "home/" + data.menuText[args.object.row];
	navOpt = {
		moduleName: modName,
		context: {
			menuOn: data.menuOn,
			menuSize: data.menuSize,
			menuText: data.menuText,
			currentIndex: args.object.row,
			vm: vm
		}
	}
	frame.topmost().navigate(navOpt);
}

function pullMenu(args) {
	page = args.object.page;
	var vm = page.bindingContext;
	var menuSwitch;
	if (vm.get("menuOn") == "visible") {
		menuSwitch = "collapse";
	}
	else {
		menuSwitch = "visible";
	}
	vm.set("menuOn", menuSwitch);
	page.bindingContext = vm;
}

exports.goto = goto;
exports.pullMenu = pullMenu;
exports.onNavigatingTo = onNavigatingTo;
