/*
In NativeScript, a file with the same name as an XML file is known as
a code-behind file. The code-behind is a great place to place your view
logic, and to set up your page’s data binding.
*/

const HomeViewModel = require("./home-view-model");
const view = require("tns-core-modules/ui/core/view");
const frame = require("tns-core-modules/ui/frame");
const observable = require("tns-core-modules/data/observable");
const scrollView = require("tns-core-modules/ui/scroll-view");
const gridLayout = require("tns-core-modules/ui/layouts/grid-layout");
const label = require("tns-core-modules/ui/label");
const textField = require("tns-core-modules/ui/text-field");
const button = require("tns-core-modules/ui/button");
const pswitch = require("tns-core-modules/ui/switch");
const dialogs = require("tns-core-modules/ui/dialogs");


function onNavigatingTo(args) {
    const page = args.object;
    data = page.navigationContext;
    vm = data.vm;
    vm.set("menuOn", data.menuOn);
    var menuRows = "";
    var menuGrid = new gridLayout.GridLayout();
    menuGrid = page.getViewById("menuGrid");
    for (i = 0; i < data.menuSize; i++) {
        if (i == 0)
            menuRows += "40";
        else
            menuRows += ", 40";
        var b = new button.Button();
        b.text = data.menuText[i];
        b.class = vm.get("tab");
        if (i == data.currentIndex) {
            b.class = vm.get("tabon");
        }
        else {
            b.on("tap", (goto));
        }
        b.row = "" + i;
        menuGrid.addChild(b);
    }
    page.css = "label { color: " + vm.get("tColor") + " } textView { color: " + vm.get("tColor") + " }";
    menuGrid.rows = menuRows;

    //////////////////////////////////code for adding monster info
    if (data.monster != null) {
        vm.set("name", data.monster.Name);
        vm.set("size", data.monster.Size);
        vm.set("type", data.monster.Type);
        vm.set("tag", data.monster.Tag);
        vm.set("alignment", data.monster.Alignment);
        vm.set("AC", data.monster.AC);
        vm.set("HP", data.monster.HitPoints[1]);
        vm.set("Speed", data.monster.Speed);
        vm.set("Strength", data.monster.Strength);
        vm.set("Dexterity", data.monster.Dexterity);
        vm.set("Intelligence", data.monster.Intelligence);
        vm.set("Constitution", data.monster.Constitution);
        vm.set("Wisdom", data.monster.Wisdom);
        vm.set("Charisma", data.monster.Charisma);
        vm.set("SavingThrows", data.monster.Description.SavingThrows);
        vm.set("Skills", data.monster.Description.Skills);
        vm.set("Vulnerabilities", data.monster.Description.DamageVulnerabilities);
        vm.set("Resistances", data.monster.Description.DamageResistances);
        vm.set("Immunities", data.monster.Description.DamageImmunities);
        vm.set("ConditionImmunities", data.monster.Description.ConditionImmunities);
        vm.set("Senses", data.monster.Description.Senses);
        vm.set("Languages", data.monster.Description.Languages);
        vm.set("Challenge", data.monster.Description.Challenge);

        vm.set("editable", false);

        if (data.monster.Name == "") {
        	page.getViewById("edit").text = "Save";
        	page.getViewById("del").text = "Cancel";
        	vm.set("editable", true);
        }

    }
    else
    {
        vm.set("editable", true);

    }


    page.bindingContext = vm;
}

function goto(args) {
    var modName = "home/" + data.menuText[args.object.row]
    navOpt = {
        moduleName: modName,
        context: {
            menuOn: data.menuOn,
            menuSize: data.menuSize,
            menuText: data.menuText,
            currentIndex: args.object.row,
            vm: vm
        }
    }
    frame.topmost().navigate(navOpt);
}

function pullMenu(args) {
    page = args.object.page;
    var vm = page.bindingContext;
    var menuSwitch;
    if (vm.get("menuOn") == "visible") {
        menuSwitch = "collapse";
    }
    else {
        menuSwitch = "visible";
    }
    vm.set("menuOn", menuSwitch);
    page.bindingContext = vm;
}



function onScroll(args) {
    const page = args.object.page;
    const vm = page.bindingContext;
    vm.set("status", "scrolling");
    setTimeout(() => {
        vm.set("status", "not scrolling");
    }, 300);
}

function edit(args)
{
    const page = args.object.page;
    const vm = page.bindingContext;
    const data = page.navigationContext;

    if (vm.get("editable") == false)
    {
        vm.set("editable", true);

        page.getViewById("edit").text = "Save";
        page.getViewById("del").text = "Cancel";
    }
    else
    {
        dialogs.confirm({
            title: "Save",
            message: "Are you sure you want to save your changes?",
            okButtonText: "Yes",
            cancelButtonText: "No"
        }).then(function (r) {
            if (r.result = true) {
                const fs = require('file-system');
                const f = fs.knownFolders.currentApp().getFile("monsters.txt");

                data.monster.Name = vm.get("name");
                data.monster.Size = vm.get("size");
                data.monster.Type = vm.get("type");
                data.monster.Tag = vm.get("tag");
                data.monster.Alignment = vm.get("alignment");
                data.monster.AC = vm.get("AC");
                data.monster.HitPoints[1] = vm.get("HP");
                var hp = vm.get("HP");
                var hp2 = "";
                var check = true;
                for (var i = 0; i < vm.get("HP").length && check; i++)
                {
                    if (hp[i] == " " || hp[i] == "(")
                    {
                        check = false;
                    }
                    else
                    {
                        hp2 += hp[i];
                    }
                    
                }
                data.monster.HitPoints[0] = parseInt(hp2);

                data.monster.Speed = vm.get("Speed");
                data.monster.Strength = vm.get("Strength");
                data.monster.Dexterity = vm.get("Dexterity");
                data.monster.Intelligence = vm.get("Intelligence");
                data.monster.Constitution = vm.get("Constitution");
                data.monster.Wisdom = vm.get("Wisdom");
                data.monster.Charisma = vm.get("Charisma");
                data.monster.Description.SavingThrows =  vm.get("SavingThrows");
                data.monster.Description.Skills = vm.get("Skills");
                data.monster.Description.DamageVulnerabilities = vm.get("Vulnerabilities");
                data.monster.Description.DamageResistances = vm.get("Resistances");
                data.monster.Description.DamageImmunities = vm.get("Immunities");
                data.monster.Description.ConditionImmunities = vm.get("ConditionImmunities");
                data.monster.Description.Senses = vm.get("Senses");
                data.monster.Description.Languages = vm.get("Languages");
                data.monster.Description.Challenge = vm.get("Challenge");

                data.fileText[data.index] = data.monster;


                var str = JSON.stringify(data.fileText);

                f.writeText((str)).then(result => {
                    f.readText().then(res => {
                        //console.log(res);
                    });
                    //console.log("check");
                    //obj = JSON.parse(str);
                }).catch(err => { console.error(err); });

                var modName = "home/Monster";
                navOpt = {
                    moduleName: modName,
                    context: {
                        menuOn: data.menuOn,
                        menuSize: data.menuSize,
                        menuText: data.menuText,
                        currentIndex: args.object.row,
                        vm: vm,
                        monster: data.monster,
                        fileText: data.fileText,
                        index: data.index
                    }
                }
                frame.topmost().navigate(navOpt);
            }
        })
    }

    page.bindingContext = vm;

}

function deleteMonster(args)
{
    const page = args.object.page;
    const vm = page.bindingContext;

    if (vm.get("editable") == false) {
        dialogs.confirm({
            title: "Delete",
            message: "Are you sure you want to delete this monster?",
            okButtonText: "Yes",
            cancelButtonText: "No"
        }).then(function (r) {
            if (r.result =true)
            {
                data.fileText.splice(data.index, 1);
                const fs = require('file-system');
                const f = fs.knownFolders.currentApp().getFile("monsters.txt");
                var str = JSON.stringify(data.fileText);

                f.writeText((str)).then(result => {
                    f.readText().then(res => {
                        //console.log(res);
                    });
                    //console.log("check");
                    //obj = JSON.parse(str);
                }).catch(err => { console.error(err); });

                var modName = "home/Bestiary";
                navOpt = {
                    moduleName: modName,
                    context: {
                        menuOn: data.menuOn,
                        menuSize: data.menuSize,
                        menuText: data.menuText,
                        currentIndex: args.object.row,
                        vm: vm,
                        monster: data.monster,
                        fileText: data.fileText,
                        index: data.index
                    }
                }
                frame.topmost().navigate(navOpt);
            }
        })
    }
    else {
        dialogs.confirm({
            title: "Cancel",
            message: "Are you sure you want to cancel your changes?",
            okButtonText: "Yes",
            cancelButtonText: "No"
        }).then(function (r) {
            if (r.result = true) {
                vm.set("editable", false);
                page.getViewById("edit").text = "Edit";
                page.getViewById("del").text = "Delete";
                var modName = "home/Monster";
                navOpt = {
                    moduleName: modName,
                    context: {
                        menuOn: data.menuOn,
                        menuSize: data.menuSize,
                        menuText: data.menuText,
                        currentIndex: args.object.row,
                        vm: vm,
                        monster: data.monster,
                        fileText: data.fileText,
                        index: data.index
                    }
                }
                frame.topmost().navigate(navOpt);
            }
        })
    }

    page.bindingContext = vm;
}

exports.pullMenu = pullMenu;
exports.onNavigatingTo = onNavigatingTo;
exports.onScroll = onScroll;
exports.edit = edit;
exports.deleteMonster = deleteMonster;
