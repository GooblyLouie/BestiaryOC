/*
In NativeScript, a file with the same name as an XML file is known as
a code-behind file. The code-behind is a great place to place your view
logic, and to set up your page’s data binding.
*/

const HomeViewModel = require("./home-view-model");
const view = require("tns-core-modules/ui/core/view");
const frame = require("tns-core-modules/ui/frame");
const observable = require("tns-core-modules/data/observable");
const scrollView = require("tns-core-modules/ui/scroll-view");
const gridLayout = require("tns-core-modules/ui/layouts/grid-layout");
const label = require("tns-core-modules/ui/label");
const textField = require("tns-core-modules/ui/text-field");
const button = require("tns-core-modules/ui/button");
const pswitch = require("tns-core-modules/ui/switch");


function onNavigatingTo(args) {
    const page = args.object;
    data = page.navigationContext;
    vm = data.vm;
	vm.set("menuOn", data.menuOn);
	var menuRows = "";
	var menuGrid = new gridLayout.GridLayout();
	menuGrid = page.getViewById("menuGrid");
	for (i = 0; i < data.menuSize; i++) {
		if (i == 0)
			menuRows += "40";
		else
			menuRows += ", 40";
		var b = new button.Button();
		b.text = data.menuText[i];
		b.class = vm.get("tab");
		if (i == data.currentIndex) {
			b.class = vm.get("tabon");
		}
		else {
    		b.on("tap", (goto));
		}
		b.id = "menu" + i;
		b.row = "" + i;
    	menuGrid.addChild(b);
	}
	page.css = "label { color: " + vm.get("tColor") + " }";
	menuGrid.rows = menuRows;
    page.bindingContext = vm;
}

function goto(args) {
	var modName = "home/" + data.menuText[args.object.row]
	navOpt = {
		moduleName: modName,
		context: {
			menuOn: data.menuOn,
			menuSize: data.menuSize,
			menuText: data.menuText,
			currentIndex: args.object.row,
			vm: vm
		}
	}
	frame.topmost().navigate(navOpt);
}

function blueTheme(args) {
	vm.set("bgColor", "#222255");
	vm.set("tabon", "tabonBlue");
	vm.set("tab", "tabBlue");
	for (var i = 0; i < data.menuSize; i++) {
		args.object.page.getViewById("menu" + i).class = "tabBlue";
		if (i == data.currentIndex)
			args.object.page.getViewById("menu" + i).class = "tabonBlue";
	}
	args.object.page.bindingContext = vm;
}

function redTheme(args) {
	vm.set("bgColor", "#552222");
	vm.set("tabon", "tabonRed");
	vm.set("tab", "tabRed");
	for (var i = 0; i < data.menuSize; i++) {
		args.object.page.getViewById("menu" + i).class = "tabRed";
		if (i == data.currentIndex)
			args.object.page.getViewById("menu" + i).class = "tabonRed";
	}
	args.object.page.bindingContext = vm;
}

function greenTheme(args) {
	vm.set("bgColor", "#225522");
	vm.set("tabon", "tabonGreen");
	vm.set("tab", "tabGreen");
	for (var i = 0; i < data.menuSize; i++) {
		args.object.page.getViewById("menu" + i).class = "tabGreen";
		if (i == data.currentIndex)
			args.object.page.getViewById("menu" + i).class = "tabonGreen";
	}
	args.object.page.bindingContext = vm;
}

function dark(args) {
	page = args.object.page;
	vm.set("light", "#222222");
	vm.set("tColor", "#777777");
	page.bindingContext = vm;
	page.css = "label { color: " + vm.get("tColor") + " }";
}

function light(args) {
	page = args.object.page;
	vm.set("light", "#999999");
	vm.set("tColor", "#222222");
	page.bindingContext = vm;
	page.css = "label { color: " + vm.get("tColor") + " }";
}

function pullMenu(args) {
	page = args.object.page;
	var vm = page.bindingContext;
	var menuSwitch;
	if (vm.get("menuOn") == "visible") {
		menuSwitch = "collapse";
	}
	else {
		menuSwitch = "visible";
	}
	vm.set("menuOn", menuSwitch);
	page.bindingContext = vm;
}



function onScroll(args) {
    const page = args.object.page;
    const vm = page.bindingContext;
    vm.set("status", "scrolling");
    setTimeout(() => {
        vm.set("status", "not scrolling");
    }, 300);
}

exports.pullMenu = pullMenu;
exports.onNavigatingTo = onNavigatingTo;
exports.onScroll = onScroll;
exports.redTheme = redTheme;
exports.greenTheme = greenTheme;
exports.blueTheme = blueTheme;
exports.dark = dark;
exports.light = light;
